export class ZabbixAppConfigCtrl {
  constructor() { }
}
ZabbixAppConfigCtrl.templateUrl = 'app_config_ctrl/config.html';
